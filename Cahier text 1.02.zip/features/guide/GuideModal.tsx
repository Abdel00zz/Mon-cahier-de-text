import React, { useEffect, useMemo, useRef, useState } from 'react';
import { GUIDE_FR, GUIDE_AR } from '@/constants';
import { Modal } from '@/components/ui/modal';
import { Button } from '@/components/ui/button';
import { LangToggle, useModalLang, type ModalLang } from '@/components/ui/lang-toggle';
import { useLocale } from '@/i18n/LocaleProvider';

interface GuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

/*
 * Guide REFONDU, esprit « papier doux » :
 * Une langue à la fois (séparation nette FR / AR), choix mémorisé ;
 * Colonne de lecture étroite et très aérée (respiration entre sections) ;
 * Sommaire monolingue (latéral sur ordinateur, chips sur mobile) ;
 * Palette papier chaud (#fdfbf7 / #f4f1ea / #e8e4d9, sauge, terracotta).
 */

const LANG_KEY = 'guide_lang_v1';

/** Markdown minimal → HTML de lecture, volontairement léger et sans grandes cartes. */
const toHtml = (markdown: string, prefix: ModalLang): string => {
  let headingIndex = 0;
  const isArabic = prefix === 'ar';
  const headingFontClass = isArabic ? 'font-bold tracking-normal' : 'font-bold tracking-tight';
  const bodyClass = isArabic
    ? 'text-[17px] leading-[2] text-slate-700 sm:text-[18px]'
    : 'text-[15px] leading-7 text-slate-600 sm:text-base';
  const inline = (value: string) => value
    .replace(/\*\*(.+?)\*\*/g, '<strong class="font-extrabold text-slate-950">$1</strong>')
    .replace(/`([^`]+)`/g, '<code class="rounded-md border border-[#e2cf8f] bg-[#f3e5b6] px-1.5 py-0.5 font-mono text-[0.82em] text-slate-800">$1</code>')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" class="font-bold text-primary underline underline-offset-4 hover:text-primary/80">$1</a>');

  return markdown
    .split('\n')
    .map(line => {
      if (line.startsWith('# ')) {
        const t = line.replace('# ', '').trim();
        return `<h1 class="mb-3 ${headingFontClass} text-3xl font-black tracking-tight text-slate-950 sm:text-4xl">${t}</h1>`;
      }
      if (line.startsWith('## ')) {
        const t = line.replace('## ', '').trim();
        const id = `${prefix}-sec-${headingIndex}`;
        headingIndex++;
        return `<h2 id="${id}" class="mb-5 mt-12 scroll-mt-4 pb-1 ${headingFontClass} text-2xl font-black text-slate-950 sm:text-[26px]">${t}</h2>`;
      }
      if (line.startsWith('### ')) {
        const t = line.replace('### ', '').trim();
        return `<h3 class="mb-3 mt-8 ${headingFontClass} text-lg font-extrabold text-slate-950 sm:text-xl">${t}</h3>`;
      }

      // Les illustrations peuvent être remplacées sans toucher au composant :
      // captures statiques ou animations GIF, avec les formats web usuels.
      const imageMatch = line.match(/^!\[(.+?)\]\((\/guide\/[^\s)]+\.(?:png|jpe?g|webp|gif))\)$/i);
      if (imageMatch) {
        const [, caption, src] = imageMatch;
        return `<figure class="my-7 overflow-hidden rounded-2xl border border-[#e5d59f] bg-[#fffdf4] shadow-sm"><img src="${src}" alt="${caption}" loading="lazy" decoding="async" class="block h-auto w-full bg-[#fffdf4] object-contain"><figcaption class="px-4 py-3 text-center text-sm font-bold leading-relaxed text-slate-600">${caption}</figcaption></figure>`;
      }

      // Les étapes restent structurées, sans boîte ni pastille numérotée.
      const numListMatch = line.match(/^([0-9]+)\. \*\*(.+?)\*\* : (.+)$/);
      if (numListMatch) {
        const [, , title, desc] = numListMatch;
        return `<section class="mb-6"><h3 class="mb-1.5 ${headingFontClass} text-lg font-black text-slate-950 sm:text-xl">${title}</h3><p class="${bodyClass}">${inline(desc)}</p></section>`;
      }

      // Les actions quotidiennes utilisent le même rythme éditorial léger.
      const boldBulletMatch = line.match(/^- \*\*(.+?)\*\* : (.+)$/);
      if (boldBulletMatch) {
        const [, title, desc] = boldBulletMatch;
        return `<section class="mb-6"><h3 class="mb-1.5 ${headingFontClass} text-lg font-black text-slate-950 sm:text-xl">${title}</h3><p class="${bodyClass}">${inline(desc)}</p></section>`;
      }

      // puce simple
      if (line.startsWith('- ')) {
        const content = inline(line.replace('- ', '').trim());
        return `<div class="mb-3 flex items-start gap-3"><span class="mt-[0.85em] h-1.5 w-1.5 shrink-0 rounded-full bg-primary"></span><span class="${bodyClass}">${content}</span></div>`;
      }

      if (line.trim() === '---') return '<div class="h-4" aria-hidden="true"></div>';
      if (!line.trim()) return '';

      return `<p class="mb-5 ${bodyClass}">${inline(line)}</p>`;
    })
    .join('\n');
};

export const GuideModal: React.FC<GuideModalProps> = ({ isOpen, onClose }) => {
  const { locale } = useLocale();
  const contentRef = useRef<HTMLDivElement>(null);
  const { lang, setLang: persistLang } = useModalLang(LANG_KEY, locale === 'ar' ? 'ar' : 'fr');
  const [activeSection, setActiveSection] = useState<string>('sec-0');

  const setLang = (next: ModalLang) => {
    persistLang(next);
    // changement de langue = nouveau document : retour en haut
    setActiveSection('sec-0');
    contentRef.current?.scrollTo({ top: 0 });
  };

  useEffect(() => {
    if (isOpen) setActiveSection('sec-0');
  }, [isOpen]);

  const isAr = lang === 'ar';
  const html = useMemo(() => toHtml(isAr ? GUIDE_AR : GUIDE_FR, lang), [lang, isAr]);

  const handleScroll = () => {
    const container = contentRef.current;
    if (!container) return;
    let current = activeSection;
    for (const header of Array.from(container.querySelectorAll('h2'))) {
      const rect = header.getBoundingClientRect();
      if (rect.top - container.getBoundingClientRect().top < 120) {
        current = header.id.replace(`${lang}-`, '');
      }
    }
    if (current !== activeSection) setActiveSection(current);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={
        <div className={`flex w-full select-none flex-col justify-between gap-3 sm:items-center ${isAr ? 'sm:flex-row-reverse' : 'sm:flex-row'}`}>
          <div dir={isAr ? 'rtl' : 'ltr'} className={isAr ? 'text-right' : 'text-left'}>
            <span className={`${isAr ? 'font-bold tracking-normal' : 'font-bold tracking-tight'} text-xl font-bold text-slate-900 flex items-center gap-2`}>
              {isAr ? 'دليل الاستخدام' : "Guide d'utilisation"}
            </span>
            <span className="block text-sm font-semibold text-slate-500 mt-1">
              {isAr ? 'الأساسيات خطوة بخطوة, ببساطة ووضوح' : "L'essentiel pas à pas, simple et complet"}
            </span>
          </div>

          {/* Bascule de langue : UNE langue à la fois, choix mémorisé */}
          <LangToggle
            lang={lang}
            onChange={setLang}
            labels={{ fr: 'Français', ar: 'العربية' }}
            className="self-start sm:self-center"
          />
        </div>
      }
      maxWidth="4xl"
      hideClose={true}
      className="h-[94vh] max-w-4xl overflow-hidden sm:h-[88vh]"
      bodyClassName="flex flex-col overflow-hidden bg-card p-0 sm:p-0"
      footer={
        <div className={`flex w-full ${isAr ? 'justify-start' : 'justify-end'} pt-2`}>
          <Button type="button" dir={isAr ? 'rtl' : 'ltr'} onClick={onClose} className="px-6 font-bold bg-primary text-primary-foreground hover:bg-primary/90 w-full sm:w-auto">
            {isAr ? '\u0625\u063a\u0644\u0627\u0642' : 'Fermer le guide'}
          </Button>
        </div>
      }
    >
      <div className="flex h-full flex-1 flex-col overflow-hidden bg-card text-card-foreground">
        {/* Corps de lecture, colonne centrale très AÉRÉE, une seule langue */}
        <div
          ref={contentRef}
          onScroll={handleScroll}
          className="relative flex-1 overflow-y-auto overscroll-contain"
          style={{ scrollbarGutter: 'stable', height: '100%' }}
          dir={isAr ? 'rtl' : 'ltr'}
          lang={lang}
        >
          <div className="mx-auto max-w-3xl px-6 py-10 pb-24 sm:px-12 sm:py-14">
            <div
              className={`max-w-none ${isAr ? 'text-right' : ''}`}
              dangerouslySetInnerHTML={{ __html: html }}
            />
          </div>
        </div>
      </div>
    </Modal>
  );
};

import React, { useState, useCallback, useEffect, useMemo, useRef } from 'react';
import { useClassManager } from '@/hooks/useClassManager';
import { defaultNotificationSettings, useConfigManager } from '@/hooks/useConfigManager';
import { useOptimizedLocalStorage } from '@/hooks/useOptimizedLocalStorage';
import { DashboardSkeleton } from '@/components/ui/PageSkeleton';
import { Button } from '@/components/ui/button';
import { ClassCard } from './ClassCard';
import { ClassListItem } from './ClassListItem';
import { CreateClassModal } from './modals/CreateClassModal';
import { OnboardingModal } from './modals/OnboardingModal';
import { OnboardingPage } from './OnboardingPage';
import { ClassNotificationsModal } from './modals/ClassNotificationsModal';
import { ClassInfo, Cycle } from '@/types';
import { getBundledCalendar, localizeCalendarName, todayInMorocco } from '@/utils/calendar';
import { daysBetweenISO } from '@/utils/assessments';
import { withAbsences } from '@/utils/lateness';
import { nextSessionInfoForClass, deriveSchedules } from '@/utils/timetable';
import { ChevronDown, Plus, BookOpen } from '@/components/ui/icons';
import { migrateLessonsData } from '@/utils/dataUtils';
import { useLocale } from '@/i18n/LocaleProvider';
import { NotificationFeed, notificationFeedForClass } from '@/hooks/useNotificationFeed';

interface DashboardProps {
    onSelectClass: (classInfo: ClassInfo) => void;
    notificationFeed: NotificationFeed;
    accountTeacherName?: string;
    onOpenSchedule?: () => void;
    onOpenNotifications?: () => void;
}

type ClassDisplayMode = 'list' | 'single' | 'double';

const CLASS_DISPLAY_OPTIONS: ClassDisplayMode[] = ['list', 'single', 'double'];

/** Salutation selon l'heure, petite touche vivante, esprit app mobile. */
const getGreeting = (locale: 'fr' | 'en' | 'ar', hour: number): string => {
    if (locale === 'en') {
        if (hour < 5) return 'Good evening';
        if (hour < 13) return 'Good morning';
        if (hour < 18) return 'Good afternoon';
        return 'Good evening';
    }
    if (locale === 'ar') {
        return hour < 13 ? 'صباح الخير' : 'مساء الخير';
    }
    if (hour < 5) return 'Bonsoir';
    if (hour < 13) return 'Bonjour';
    if (hour < 18) return 'Bon après-midi';
    return 'Bonsoir';
};

const readLessons = (classId: string) => {
    try {
        const raw = localStorage.getItem(`classData_v1_${classId}`);
        const parsed = raw ? JSON.parse(raw) : [];
        return migrateLessonsData(Array.isArray(parsed) ? parsed : (parsed.lessonsData ?? []));
    } catch {
        return [];
    }
};

const findLatestDate = (data: any): string | null => {
    let latestDate: string | null = null;

    const findDate = (obj: any) => {
        if (typeof obj !== 'object' || obj === null) return;

        if (obj.date && typeof obj.date === 'string') {
            if (!latestDate || obj.date > latestDate) {
                latestDate = obj.date;
            }
        }

        Object.values(obj).forEach(value => {
            if (Array.isArray(value)) {
                value.forEach(findDate);
            } else if (typeof value === 'object') {
                findDate(value);
            }
        });
    };

    if (Array.isArray(data)) {
        data.forEach(findDate);
    } else {
        findDate(data);
    }

    return latestDate;
};

export const Dashboard: React.FC<DashboardProps> = ({
    onSelectClass,
    notificationFeed,
    accountTeacherName = '',
    onOpenSchedule,
    onOpenNotifications,
}) => {
    const { locale, t, isRtl } = useLocale();
    const { classes, addClass, deleteClass, updateClass, isLoading: isClassesLoading } = useClassManager();
    const { config, updateConfig, isLoading: isConfigLoading } = useConfigManager();
    const [isCreateModalOpen, setCreateModalOpen] = useState(false);
    const [editingClass, setEditingClass] = useState<ClassInfo | null>(null);
    const [notificationClass, setNotificationClass] = useState<ClassInfo | null>(null);
    const [isOnboardingOpen, setOnboardingOpen] = useState(false);
    const [lastModifiedDates, setLastModifiedDates] = useState<Record<string, string | null>>({});
    const { value: selectedCycle, setValue: setSelectedCycle } = useOptimizedLocalStorage<Cycle>('selected_cycle_v1', 'college', 100);
    const { value: classDisplayMode, setValue: setClassDisplayMode } = useOptimizedLocalStorage<ClassDisplayMode>('dashboard_class_display_v1', 'double', 100);
    const [cycleFilter, setCycleFilter] = useState<string>('all');
    const [isDisplayMenuOpen, setDisplayMenuOpen] = useState(false);
    const displayMenuRef = useRef<HTMLDivElement>(null);
    const [now, setNow] = useState(() => new Date());
    const teacherName = (config.defaultTeacherName || accountTeacherName).trim();

    useEffect(() => {
        if (!CLASS_DISPLAY_OPTIONS.includes(classDisplayMode)) {
            setClassDisplayMode('double');
        }
    }, [classDisplayMode, setClassDisplayMode]);

    useEffect(() => {
        const refreshClock = () => setNow(new Date());
        const timer = window.setInterval(refreshClock, 60_000);
        const refreshWhenVisible = () => {
            if (document.visibilityState === 'visible') refreshClock();
        };
        document.addEventListener('visibilitychange', refreshWhenVisible);
        return () => {
            window.clearInterval(timer);
            document.removeEventListener('visibilitychange', refreshWhenVisible);
        };
    }, []);

    const isLoading = isClassesLoading || isConfigLoading;
    const notificationCounts = useMemo(
        () => new Map(classes.map(classInfo => [
            classInfo.id,
            notificationFeedForClass(notificationFeed, classInfo).attentionCount,
        ])),
        [classes, notificationFeed],
    );
    useEffect(() => {
        if (isClassesLoading) return;

        const dates: Record<string, string | null> = {};
        classes.forEach(classInfo => {
            const lessons = readLessons(classInfo.id);
            dates[classInfo.id] = findLatestDate(lessons);
        });
        setLastModifiedDates(dates);
    }, [classes, isClassesLoading, notificationFeed]);

    useEffect(() => {
        if (!isDisplayMenuOpen) return;
        const closeMenu = (event: PointerEvent) => {
            if (!displayMenuRef.current?.contains(event.target as Node)) setDisplayMenuOpen(false);
        };
        const closeOnEscape = (event: KeyboardEvent) => {
            if (event.key === 'Escape') setDisplayMenuOpen(false);
        };
        window.addEventListener('pointerdown', closeMenu);
        window.addEventListener('keydown', closeOnEscape);
        return () => {
            window.removeEventListener('pointerdown', closeMenu);
            window.removeEventListener('keydown', closeOnEscape);
        };
    }, [isDisplayMenuOpen]);

    useEffect(() => {
        if (isConfigLoading) return;
        const preferred = config.selectedCycles?.[0] as Cycle | undefined;
        if (preferred && !config.selectedCycles?.includes(selectedCycle)) {
            setSelectedCycle(preferred);
        }
    }, [isConfigLoading, config.selectedCycles, selectedCycle, setSelectedCycle]);

    useEffect(() => {
        if (isLoading) return;
        if (classes.length > 0 && config.hasCompletedWelcome) return;
        try {
            if (sessionStorage.getItem('onboarding_seen_v1')) return;
        } catch { /* stockage indisponible */ }
        const timer = window.setTimeout(() => setOnboardingOpen(true), 600);
        return () => window.clearTimeout(timer);
    }, [isLoading, classes.length, config.hasCompletedWelcome]);

    const closeOnboarding = useCallback(() => {
        try { sessionStorage.setItem('onboarding_seen_v1', '1'); } catch { /* stockage indisponible */ }
        if (!config.hasCompletedWelcome) updateConfig({ hasCompletedWelcome: true });
        setOnboardingOpen(false);
    }, [config.hasCompletedWelcome, updateConfig]);

    const completeOnboarding = useCallback(() => {
        const current = { ...defaultNotificationSettings, ...(config.notificationSettings ?? {}) };
        updateConfig({
            hasCompletedWelcome: true,
            notificationSettings: {
                ...current,
                enabled: true,
                sessionVibration: true,
            },
        });
    }, [config.notificationSettings, updateConfig]);

    const createClass = useCallback((details: { name: string; subject: string; cycle?: Cycle }): ClassInfo => {
        const created = addClass({
            ...details,
            cycle: details.cycle ?? selectedCycle,
            teacherName: teacherName || t('settings.defaultTeacherName'),
        });
        if (details.cycle && details.cycle !== selectedCycle) {
            setSelectedCycle(details.cycle);
        }
        return created;
    }, [addClass, selectedCycle, setSelectedCycle, t, teacherName]);

    const handleCreateClass = (details: { name: string; subject: string; cycle?: Cycle }) => {
        createClass(details);
        setCreateModalOpen(false);
    };

    const handleDeleteClass = useCallback((classId: string) => {
        deleteClass(classId);
        const patch: Partial<typeof config> = {};
        if (config.assessmentDates?.[classId]) {
            const next = { ...config.assessmentDates }; delete next[classId]; patch.assessmentDates = next;
        }
        if (config.assessmentAbsences?.[classId]) {
            const next = { ...config.assessmentAbsences }; delete next[classId]; patch.assessmentAbsences = next;
        }
        if (config.pedagogicalEvents?.[classId]) {
            const next = { ...config.pedagogicalEvents }; delete next[classId]; patch.pedagogicalEvents = next;
        }
        if (config.notificationDismissals?.[classId]) {
            const next = { ...config.notificationDismissals }; delete next[classId]; patch.notificationDismissals = next;
        }
        if (config.timetable?.some(e => e.classId === classId)) {
            const nextTimetable = config.timetable.filter(e => e.classId !== classId);
            patch.timetable = nextTimetable;
            patch.schedules = deriveSchedules(nextTimetable);
        }
        if (Object.keys(patch).length > 0) updateConfig(patch);
    }, [deleteClass, config.assessmentDates, config.assessmentAbsences, config.pedagogicalEvents, config.notificationDismissals, config.timetable, updateConfig]);

    const availableCycles = useMemo(() => {
        const set = new Set<string>();
        classes.forEach(c => { if (c.cycle) set.add(c.cycle); });
        return Array.from(set);
    }, [classes]);

    if (isLoading) {
        return <DashboardSkeleton />;
    }

    const calendar = getBundledCalendar();
    const calendarWithAbsences = withAbsences(calendar, config.absences);
    const nextSession = (classId: string) =>
        nextSessionInfoForClass(
            classId,
            config.timetable,
            config.schedules?.find(s => s.classId === classId)?.slots.map(s => s.weekday) ?? [],
            calendarWithAbsences,
            locale,
            now,
            config.schoolYearStart,
        );

    const todayISO = todayInMorocco(now, calendar);
    const holidayToday = calendar.joursFeries.find(item => item.date === todayISO);
    const vacationToday = calendar.vacances.find(item => todayISO >= item.debut && todayISO <= item.fin);
    const assessmentsThisWeek = notificationFeed.assessments.filter(item => {
        const inDays = daysBetweenISO(todayISO, item.dateISO);
        return inDays >= 0 && inDays <= 6;
    }).length;
    const sessionStates = classes.map(classInfo => nextSession(classInfo.id)?.kind).filter(Boolean);
    const hasCurrentSession = sessionStates.includes('now');
    const hasSessionToday = sessionStates.includes('today');
    const localeCode = locale === 'ar' ? 'ar-MA' : locale === 'en' ? 'en-GB' : 'fr-MA';
    let currentHour = now.getHours();
    try {
        currentHour = Number(new Intl.DateTimeFormat('en-GB', {
            timeZone: calendar.fuseau,
            hour: '2-digit',
            hourCycle: 'h23',
        }).format(now));
    } catch {
        // Le fuseau local du navigateur reste un repli sûr.
    }
    const todayLabel = new Intl.DateTimeFormat(localeCode, {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        timeZone: calendar.fuseau,
    }).format(now);
    const vacationResumeISO = vacationToday
        ? (() => {
            const nextDay = new Date(`${vacationToday.fin}T12:00:00Z`);
            nextDay.setUTCDate(nextDay.getUTCDate() + 1);
            const calendarResume = nextDay.toISOString().slice(0, 10);
            return config.schoolYearStart && config.schoolYearStart > vacationToday.fin
                ? config.schoolYearStart
                : calendarResume;
        })()
        : '';
    const vacationResumeLabel = vacationResumeISO
        ? new Intl.DateTimeFormat(localeCode, { day: 'numeric', month: 'long', timeZone: 'UTC' }).format(new Date(`${vacationResumeISO}T12:00:00Z`))
        : '';
    const timeDetailKey = currentHour < 13
        ? 'dashboard.welcome.morningDetail'
        : currentHour < 18
            ? 'dashboard.welcome.afternoonDetail'
            : 'dashboard.welcome.eveningDetail';
    const welcome: { eyebrow: string; title: string; detail: string } = (() => {
        if (classes.length === 0) {
            return {
                eyebrow: t('dashboard.welcome.startLabel'),
                title: t('dashboard.welcome.startTitle'),
                detail: t('dashboard.welcome.startDetail'),
            };
        }
        if (holidayToday) {
            return {
                eyebrow: localizeCalendarName(holidayToday.nom, locale),
                title: t('dashboard.welcome.holidayTitle'),
                detail: t('dashboard.welcome.holidayDetail'),
            };
        }
        if (vacationToday) {
            return {
                eyebrow: localizeCalendarName(vacationToday.nom, locale),
                title: '',
                detail: t('dashboard.welcome.vacationDetail', { date: vacationResumeLabel }),
            };
        }
        if (assessmentsThisWeek > 0) {
            return {
                eyebrow: t('dashboard.welcome.assessmentsLabel'),
                title: t(assessmentsThisWeek === 1 ? 'dashboard.welcome.assessmentTitleOne' : 'dashboard.welcome.assessmentTitleMany', { count: assessmentsThisWeek }),
                detail: t('dashboard.welcome.assessmentsDetail'),
            };
        }
        if (hasCurrentSession) {
            return {
                eyebrow: t('dashboard.welcome.nowLabel'),
                title: t('dashboard.welcome.nowTitle'),
                detail: t('dashboard.welcome.nowDetail'),
            };
        }
        if (hasSessionToday) {
            return {
                eyebrow: t('dashboard.welcome.todayLabel'),
                title: t('dashboard.welcome.todayTitle'),
                detail: t('dashboard.welcome.todayDetail'),
            };
        }
        return {
            eyebrow: todayLabel,
            title: '',
            detail: t(timeDetailKey),
        };
    })();
    const greeting = getGreeting(locale, currentHour);
    const teacherNameIsArabic = /[\u0600-\u06FF]/.test(teacherName);

    const visibleClasses = [...classes]
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const filteredClasses = visibleClasses.filter(c => {
        if (cycleFilter !== 'all' && c.cycle !== cycleFilter) return false;
        return true;
    });

    const currentDisplay = CLASS_DISPLAY_OPTIONS.includes(classDisplayMode) ? classDisplayMode : 'double';
    const classGridClass = currentDisplay === 'single'
        ? 'grid-cols-1'
        : 'grid-cols-1 landscape:grid-cols-2 sm:grid-cols-2';

    const displayCopy = (value: ClassDisplayMode) => {
        const keys: Record<ClassDisplayMode, [string, string]> = {
            list: ['dashboard.display.list', 'dashboard.display.listDescription'],
            single: ['dashboard.display.single', 'dashboard.display.singleDescription'],
            double: ['dashboard.display.double', 'dashboard.display.doubleDescription'],
        };
        const [labelKey, descriptionKey] = keys[value];
        return { label: t(labelKey), description: t(descriptionKey) };
    };

    // Page de démarrage immersive (première connexion, aucun cahier)
    if (isOnboardingOpen && classes.length === 0) {
        return (
            <OnboardingPage
                config={config}
                onConfigChange={updateConfig}
                classes={classes}
                onCreateClass={createClass}
                onOpenNotebook={onSelectClass}
                onComplete={completeOnboarding}
                onSkip={closeOnboarding}
            />
        );
    }

    return (
        <div className="min-h-screen bg-transparent text-foreground antialiased dark:bg-zinc-950 pb-20 sm:pb-8" data-dashboard-root>
            <div className="relative min-w-0 overflow-x-clip" data-dashboard-main>
                <div className="relative z-10 mx-auto max-w-[1440px] px-4 py-5 sm:px-7 sm:py-7 lg:px-10">
                    <header className="mb-8 space-y-4" id="dashboard-header">
                        <div className="flex items-center gap-3">
                            <div className="min-w-0">
                                <p className={`mb-1 text-[10px] font-bold text-muted-foreground ${isRtl ? 'tracking-normal' : 'uppercase tracking-[0.12em]'}`}>{welcome.eyebrow}</p>
                                <h1 className="flex flex-wrap items-baseline gap-x-1 text-xl font-bold tracking-tight text-foreground dark:text-white sm:text-2xl">
                                    <span>{greeting}{teacherName ? (locale === 'ar' ? '،' : ',') : ''}</span>
                                    {teacherName && (
                                        <span
                                            dir={teacherNameIsArabic ? 'rtl' : 'ltr'}
                                            className={`font-sans text-[0.92em] leading-none font-normal text-blue-600`}
                                        >
                                            {teacherName}
                                        </span>
                                    )}
                                </h1>
                                <p className="mt-1 max-w-2xl text-xs font-medium leading-relaxed text-muted-foreground sm:text-[13px]">
                                    {welcome.title && <span className="font-bold text-zinc-600 dark:text-zinc-300">{welcome.title}</span>}
                                    {welcome.title && welcome.detail && <span aria-hidden="true"> · </span>}
                                    <span>{welcome.detail}</span>
                                </p>
                            </div>
                        </div>

                        {classes.length > 0 && availableCycles.length > 1 && (
                            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                                <button
                                    type="button"
                                    onClick={() => setCycleFilter('all')}
                                    className={`shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold transition-all ${
                                        cycleFilter === 'all'
                                            ? 'bg-primary text-primary-foreground shadow-sm'
                                            : 'border border-border/65 bg-card/80 text-muted-foreground shadow-2xs hover:border-primary/20 hover:text-foreground dark:bg-zinc-900'
                                    }`}
                                >
                                    {t('dashboard.filterAll')}
                                </button>
                                {availableCycles.map(c => {
                                    return (
                                        <button
                                            key={c}
                                            type="button"
                                            onClick={() => setCycleFilter(c)}
                                            className={`shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold transition-all ${
                                                cycleFilter === c
                                                    ? 'bg-primary text-primary-foreground shadow-sm'
                                                    : 'border border-border/65 bg-card/80 text-muted-foreground shadow-2xs hover:border-primary/20 hover:text-foreground dark:bg-zinc-900'
                                            }`}
                                        >
                                            {t(`cycle.${c}`)}
                                        </button>
                                    );
                                })}
                            </div>
                        )}
                    </header>

                    <main>
                        <section className="w-full" aria-labelledby="classes-heading">
                            <div className="mb-5 flex items-center justify-between gap-3 flex-wrap">
                                <div className="flex items-center gap-2.5">
                                    <h2 id="classes-heading" className="text-xl font-bold text-foreground dark:text-white flex items-center gap-1.5">
                                        <span>{t('dashboard.classes')}</span>
                                        {filteredClasses.length > 0 && (
                                            <span className="text-muted-foreground dark:text-muted-foreground font-medium text-sm">
                                                ({filteredClasses.length})
                                            </span>
                                        )}
                                    </h2>
                                </div>

                                <div className="flex items-center gap-2">
                                    <Button
                                        type="button"
                                        onClick={() => setCreateModalOpen(true)}
                                        className="h-8 sm:h-8.5 px-2.5 sm:px-3 rounded-full bg-primary hover:bg-primary/90 active:bg-primary/85 text-primary-foreground font-bold text-xs flex items-center gap-1 sm:gap-1.5 shadow-2xs hover:shadow-xs transition-all hover:scale-[1.03] active:scale-[0.97] cursor-pointer"
                                        aria-label={t('dashboard.addClass')}
                                        title={t('dashboard.addClass')}
                                    >
                                        <Plus className="h-3.5 w-3.5 stroke-[2.5]" />
                                        <span>{t('dashboard.classShort')}</span>
                                    </Button>

                                    {classes.length > 0 && (
                                        <div ref={displayMenuRef} className="relative shrink-0 hidden sm:block">
                                            <button
                                                type="button"
                                                onClick={() => setDisplayMenuOpen(open => !open)}
                                                aria-haspopup="menu"
                                                aria-expanded={isDisplayMenuOpen}
                                                className="flex h-8 sm:h-8.5 items-center gap-2 rounded-full bg-card/85 px-3 text-xs font-semibold text-foreground shadow-2xs hover:border-primary/20 active:scale-[0.98] border border-border/70"
                                            >
                                                <span>{displayCopy(currentDisplay).label}</span>
                                                <ChevronDown className={`h-3 w-3 text-muted-foreground transition-transform ${isDisplayMenuOpen ? 'rotate-180' : ''}`} />
                                            </button>
                                            {isDisplayMenuOpen && (
                                                <div
                                                    role="menu"
                                                    className={`absolute top-[calc(100%+0.4rem)] z-30 w-44 overflow-hidden rounded-[16px] border border-border/70 bg-popover/95 p-2 shadow-[0_16px_40px_rgba(30,64,110,0.12)] backdrop-blur-xl dark:bg-zinc-800 ${isRtl ? 'left-0' : 'right-0'}`}
                                                >
                                                    {CLASS_DISPLAY_OPTIONS.map(option => {
                                                        const isActive = option === currentDisplay;
                                                        return (
                                                            <button
                                                                key={option}
                                                                type="button"
                                                                role="menuitemradio"
                                                                aria-checked={isActive}
                                                                onClick={() => {
                                                                    setClassDisplayMode(option);
                                                                    setDisplayMenuOpen(false);
                                                                }}
                                                                className={`flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left transition-colors ${isActive ? 'bg-primary/10 text-primary dark:bg-blue-900/30 dark:text-blue-300' : 'text-muted-foreground dark:text-muted-foreground hover:bg-muted dark:hover:bg-zinc-700/50 hover:text-foreground dark:hover:text-white'}`}
                                                            >
                                                                <span className="text-[12px] font-bold">{displayCopy(option).label}</span>
                                                            </button>
                                                        );
                                                    })}
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </div>
                            </div>
                                {classes.length === 0 ? (
                                    <div className="flex flex-col items-center gap-4 rounded-[22px] border border-border/65 bg-card/86 px-6 py-12 text-center shadow-[0_16px_44px_rgba(30,64,110,0.06)] backdrop-blur-sm">
                                        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/8 text-primary">
                                            <BookOpen className="h-6 w-6" />
                                        </div>
                                        <div>
                                            <h3 className="text-base font-bold text-foreground dark:text-white">{t('dashboard.emptyTitle')}</h3>
                                            <p className="mt-1.5 text-sm text-muted-foreground dark:text-muted-foreground max-w-sm">
                                                {t('dashboard.emptyDescription')}
                                            </p>
                                            </div>
                                            <Button onClick={() => setOnboardingOpen(true)} className="mt-4 h-10 rounded-xl bg-primary px-6 font-bold text-primary-foreground hover:bg-primary/90">
                                            {t('dashboard.addClass')}
                                        </Button>
                                    </div>
                                ) : currentDisplay === 'list' ? (
                                    <div className="space-y-3" role="list" aria-label={t('dashboard.classList')}>
                                        {filteredClasses.map((classInfo, index) => (
                                            <div
                                                key={classInfo.id}
                                                role="listitem"
                                                className="animate-in slide-in-from-bottom-4 fade-in duration-200"
                                                style={{ animationDelay: `${Math.min(index, 8) * 35}ms`, animationFillMode: 'backwards' }}
                                            >
                                                <ClassListItem
                                                    classInfo={classInfo}
                                                    onSelect={() => onSelectClass(classInfo)}
                                                    onConfigure={() => setEditingClass(classInfo)}
                                                    onShowNotifications={() => setNotificationClass(classInfo)}
                                                    notificationCount={notificationCounts.get(classInfo.id) ?? 0}
                                                />
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <div className={`grid ${classGridClass} gap-3 sm:gap-4`}>
                                        {filteredClasses.map((classInfo, index) => (
                                            <div
                                                key={classInfo.id}
                                                className="h-full animate-in slide-in-from-bottom-4 fade-in duration-200"
                                                style={{ animationDelay: `${Math.min(index, 8) * 45}ms`, animationFillMode: 'backwards' }}
                                            >
                                                <ClassCard
                                                    classInfo={classInfo}
                                                    onSelect={() => onSelectClass(classInfo)}
                                                    onConfigure={() => setEditingClass(classInfo)}
                                                    onShowNotifications={() => setNotificationClass(classInfo)}
                                                    notificationCount={notificationCounts.get(classInfo.id) ?? 0}
                                                />
                                            </div>
                                        ))}
                                    </div>
                                )}
                        </section>
                    </main>
                </div>
            </div>

            <CreateClassModal
                isOpen={isCreateModalOpen || !!editingClass}
                onClose={() => {
                    setCreateModalOpen(false);
                    setEditingClass(null);
                }}
                onCreate={handleCreateClass}
                defaultTeacherName={teacherName}
                defaultCycle={selectedCycle}
                teacherSubjects={config.selectedSubjects}
                teacherCycles={config.showAllCycles ? undefined : (config.selectedCycles as Cycle[] | undefined)}
                existingClasses={classes}
                editingClass={editingClass}
                onUpdate={(classId, updates) => {
                    updateClass(classId, updates);
                    setEditingClass(null);
                }}
                onDelete={editingClass ? () => {
                    handleDeleteClass(editingClass.id);
                    setEditingClass(null);
                } : undefined}
            />
            <OnboardingModal
                isOpen={isOnboardingOpen}
                onClose={closeOnboarding}
                onComplete={completeOnboarding}
                config={config}
                onConfigChange={updateConfig}
                classes={classes}
                onCreateClass={createClass}
                onOpenNotebook={onSelectClass}
            />
            <ClassNotificationsModal
                isOpen={!!notificationClass}
                classInfo={notificationClass}
                config={config}
                feed={notificationFeed}
                lastModified={notificationClass ? lastModifiedDates[notificationClass.id] : null}
                nextSession={notificationClass ? nextSession(notificationClass.id) : null}
                onClose={() => setNotificationClass(null)}
                onSelectClass={onSelectClass}
                onOpenSchedule={onOpenSchedule}
                onOpenNotifications={onOpenNotifications}
            />
        </div>
    );
};

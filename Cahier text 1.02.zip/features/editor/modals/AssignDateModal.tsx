import { FC, useEffect, useMemo, useState } from 'react';
import { Modal } from '@/components/ui/modal';
import { CalendarX, CalendarPlus, CalendarMinus, ChevronRight } from '@/components/ui/icons';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Segmented } from '@/components/ui/segmented';
import { MathJax } from 'better-react-mathjax';
import { Indices } from '@/types';
import { TYPE_MAP, BADGE_COLOR_MAP, TOP_LEVEL_TYPE_CONFIG } from '@/constants';
import { todayInMorocco } from '@/utils/calendar';
import { hasMathSyntax } from '@/utils/math';
import { useLocale } from '@/i18n/LocaleProvider';

interface SelectedItemPreview {
  indices: Indices;
  item: any;
  title: string;
  date?: string;
  description?: string;
  canDate: boolean;
}

interface AssignDateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApply: (date: string) => void;
  selectedCount: number;
  selectedItems: SelectedItemPreview[];
  /** validation intelligente : alertes live pour la date choisie (emploi du temps, fériés, vacances, absences) */
  getDateWarnings?: (date: string) => { type: string; message: string }[];
  /** Date conservée lors d'un retour depuis la vérification. */
  initialDate?: string;
}

const addDaysISO = (iso: string, offset: number): string => {
  const [year, month, day] = iso.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  date.setUTCDate(date.getUTCDate() + offset);
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}-${String(date.getUTCDate()).padStart(2, '0')}`;
};

const isoFromOffset = (offset: number) => {
  return addDaysISO(todayInMorocco(), offset);
};

const formatShortDate = (dateStr: string | undefined, localeCode: string, emptyLabel: string) => {
  if (!dateStr) return emptyLabel;
  try {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const y = Number(parts[0]);
      const m = Number(parts[1]);
      const d = Number(parts[2]);
      const dateObj = new Date(y, m - 1, d);
      return dateObj.toLocaleDateString(localeCode, { day: 'numeric', month: 'short' });
    }
    const dObj = new Date(dateStr);
    if (isNaN(dObj.getTime())) return dateStr;
    return dObj.toLocaleDateString(localeCode, { day: 'numeric', month: 'short' });
  } catch {
    return dateStr;
  }
};

const formatFullDate = (dateStr: string | undefined, localeCode: string, emptyLabel: string) => {
  if (!dateStr) return emptyLabel;
  try {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const y = Number(parts[0]);
      const m = Number(parts[1]);
      const d = Number(parts[2]);
      const dateObj = new Date(y, m - 1, d);
      return dateObj.toLocaleDateString(localeCode, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    }
    const dObj = new Date(dateStr);
    if (isNaN(dObj.getTime())) return dateStr;
    return dObj.toLocaleDateString(localeCode, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  } catch {
    return dateStr;
  }
};

export const AssignDateModal: FC<AssignDateModalProps> = ({
  isOpen,
  onClose,
  onApply,
  selectedCount,
  selectedItems,
  getDateWarnings,
  initialDate,
}) => {
  const { t, locale, isRtl } = useLocale();
  const localeCode = locale === 'ar' ? 'ar-MA' : locale === 'en' ? 'en-GB' : 'fr-MA';
  const number = useMemo(() => new Intl.NumberFormat(localeCode), [localeCode]);
  const [actionType, setActionType] = useState<'associate' | 'dissociate'>('associate');
  const [selectedDate, setSelectedDate] = useState(() => isoFromOffset(0));

  useEffect(() => {
    if (!isOpen) return;
    setActionType('associate');
    setSelectedDate(initialDate || isoFromOffset(0));
  }, [initialDate, isOpen]);

  // Alertes live : recalculées à chaque changement de date choisie.
  const dateWarnings = useMemo(
    () => (actionType === 'associate' && getDateWarnings && selectedDate ? getDateWarnings(selectedDate) : []),
    [actionType, getDateWarnings, selectedDate]
  );

  const getItemBadge = (item: any) => {
    if (!item) return null;
    const type = item.type || '';
    if (!type) return null;

    if (TOP_LEVEL_TYPE_CONFIG.hasOwnProperty(type)) {
      const config = TOP_LEVEL_TYPE_CONFIG[type];
      return {
        text: t(`manageLessons.type.${type}`),
        color: config.badgeColor || 'bg-secondary text-secondary-foreground border-border',
        icon: config.icon
      };
    }

    const normalizedType = TYPE_MAP[type.toLowerCase()] || type;
    const text = t(`contentType.short.${normalizedType}`);
    const color = BADGE_COLOR_MAP[normalizedType] || 'bg-secondary text-secondary-foreground border-border';

    return { text, color, icon: null };
  };

  const handleApply = () => {
    if (actionType === 'associate') {
      onApply(selectedDate);
    } else {
      onApply(''); // Empty string dissociates the date
    }
  };

  const maxItemsToShow = 3;
  const remainingItemsCount = Math.max(0, selectedItems.length - maxItemsToShow);
  const visibleItems = useMemo(() => {
    return selectedItems.slice(0, maxItemsToShow);
  }, [selectedItems]);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={t('assignDate.title')}
      description={t(selectedCount === 1 ? 'assignDate.selectedOne' : 'assignDate.selectedMany', { count: number.format(selectedCount) })}
      maxWidth="md"
      footer={
        <div className="flex items-center justify-end gap-2 w-full">
          <Button type="button" variant="secondary" onClick={onClose} className="px-3 text-xs font-semibold">
            {t('common.cancel')}
          </Button>
          <Button
            type="button"
            onClick={handleApply}
            className={`cursor-pointer px-3.5 text-xs font-bold shadow-sm transition-all duration-150 ${
              actionType === 'associate'
                ? 'bg-primary hover:bg-primary/90 text-primary-foreground'
                : 'bg-rose-600 hover:bg-rose-700 text-white'
            }`}
          >
            {actionType === 'associate' ? (
              <span>{t('assignDate.applyDate')}</span>
            ) : (
              <span>{t('assignDate.removeDates')}</span>
            )}
          </Button>
        </div>
      }
    >
      <div className="space-y-4">
        {/* Sleek toggle selector */}
        <Segmented<'associate' | 'dissociate'>
          value={actionType}
          onChange={setActionType}
          className="grid w-full grid-cols-2 max-w-sm mx-auto"
          options={[
            {
              value: 'associate',
              label: (
                <span className="flex items-center gap-1.5">
                  <CalendarPlus className="h-3 w-3" /> {t('assignDate.assign')}
                </span>
              ),
            },
            {
              value: 'dissociate',
              label: (
                <span className="flex items-center gap-1.5">
                  <CalendarMinus className="h-3 w-3" /> {t('assignDate.unassign')}
                </span>
              ),
            },
          ]}
        />

        {/* Dynamic & Centered Middle Section */}
        {actionType === 'associate' ? (
          <div className="space-y-3.5 animate-fade-in duration-200 text-center max-w-sm mx-auto py-1">
            <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider block">
              {t('assignDate.chooseDate')}
            </span>
            
            {/* Centered Date Input */}
            <div className="relative flex flex-col items-center gap-1.5">
              <Input
                id="assign-date-input"
                type="date"
                value={selectedDate}
                onChange={event => setSelectedDate(event.target.value)}
                className="h-10 w-48 rounded-lg border border-border bg-card text-center text-sm font-bold shadow-xs transition-colors hover:bg-muted focus:border-border focus:ring-0"
              />
              {/* Intelligent date readout / Capteur intelligent */}
              <span className="text-xs font-semibold text-muted-foreground capitalize">
                {formatFullDate(selectedDate, localeCode, t('assignDate.noDateSelected'))}
              </span>
            </div>

            {/* Garde intelligente : conflits emploi du temps / fériés / vacances / absences */}
            {dateWarnings.length > 0 && (
              <div className="mx-auto max-w-sm space-y-1 rounded-xl border border-amber-200 bg-amber-50/60 p-3 text-start animate-fade-in duration-200" role="status">
                {dateWarnings.map((warning, i) => (
                  <p key={i} className="flex items-start gap-1.5 text-[11px] font-medium leading-snug text-amber-800">
                    <span aria-hidden className="mt-0.5 shrink-0 text-amber-600">⚠</span>
                    {warning.message}
                  </p>
                ))}
                <p className="pl-4 text-[10px] text-amber-600/95 font-medium mt-1">
                  {t('assignDate.warningOverride')}
                </p>
              </div>
            )}

            {/* Quick Presets */}
            <div className="grid grid-cols-3 gap-1.5 max-w-xs mx-auto pt-1">
              <Button
                type="button"
                className={`h-10 rounded-lg border border-border py-1 text-[11px] font-bold shadow-xs transition-all duration-150 active:scale-95 ${
                  selectedDate === isoFromOffset(-1)
                    ? 'bg-primary text-primary-foreground border-primary font-extrabold'
                    : 'bg-card hover:bg-muted text-foreground'
                }`}
                onClick={() => setSelectedDate(isoFromOffset(-1))}
              >
                {t('assignDate.yesterday')}
              </Button>
              <Button
                type="button"
                className={`h-10 rounded-lg border border-border py-1 text-[11px] font-bold shadow-xs transition-all duration-150 active:scale-95 ${
                  selectedDate === isoFromOffset(0)
                    ? 'bg-primary text-primary-foreground border-primary font-extrabold'
                    : 'bg-card hover:bg-muted text-foreground'
                }`}
                onClick={() => setSelectedDate(isoFromOffset(0))}
              >
                {t('assignDate.today')}
              </Button>
              <Button
                type="button"
                className={`h-10 rounded-lg border border-border py-1 text-[11px] font-bold shadow-xs transition-all duration-150 active:scale-95 ${
                  selectedDate === isoFromOffset(1)
                    ? 'bg-primary text-primary-foreground border-primary font-extrabold'
                    : 'bg-card hover:bg-muted text-foreground'
                }`}
                onClick={() => setSelectedDate(isoFromOffset(1))}
              >
                {t('assignDate.tomorrow')}
              </Button>
            </div>
          </div>
        ) : (
          <div className="mx-auto max-w-sm animate-fade-in duration-200 space-y-1.5 rounded-lg border border-rose-200 bg-rose-50 p-3 text-center">
            <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-rose-100 text-rose-600 mb-0.5">
              <CalendarX className="h-4 w-4" />
            </div>
            <h4 className="text-xs font-bold text-rose-800 uppercase tracking-wider">{t('assignDate.removeTitle')}</h4>
            <p className="text-[11px] text-rose-600 font-medium leading-relaxed max-w-xs mx-auto">
              {t('assignDate.removeHint')}
            </p>
          </div>
        )}

        {/* Compact selected items list preview with transition preview */}
        <div className="space-y-1.5 pt-1">
          <div className="flex items-center justify-between text-[10px] font-bold text-muted-foreground uppercase tracking-wider px-1">
            <span>{t('assignDate.preview')}</span>
            <span>{t('assignDate.change')}</span>
          </div>
          
          <div className="rounded-xl border border-border bg-muted/50 p-1.5 space-y-1">
            {visibleItems.map((previewItem, index) => {
              const badge = getItemBadge(previewItem.item);
              const isDateable = previewItem.canDate;

              return (
                <div
                  key={`${previewItem.title}-${index}`}
                  className={`flex items-center justify-between gap-3 p-1.5 rounded-lg border border-border bg-card shadow-xs transition-opacity duration-150 ${
                    !isDateable ? 'opacity-40' : ''
                  }`}
                >
                  {/* Left Side: Badge & Title */}
                  <div className="flex items-center gap-1.5 min-w-0 flex-1">
                    {badge && (
                      <Badge
                        variant="outline"
                        className={`text-[8.5px] font-bold uppercase py-0 px-1 h-4 rounded flex items-center gap-0.5 flex-shrink-0 ${badge.color}`}
                      >
                        {badge.icon && <badge.icon className="me-0.5 h-2 w-2" />}
                        {badge.text}
                      </Badge>
                    )}

                    <div className="min-w-0 flex-grow text-[11px] font-semibold text-foreground truncate">
                      {hasMathSyntax(previewItem.title) ? (
                        <MathJax inline hideUntilTypeset="first">
                          {previewItem.title}
                        </MathJax>
                      ) : (
                        <span>{previewItem.title || t('assignDate.untitled')}</span>
                      )}
                    </div>
                  </div>

                  {/* Right Side: Visual state change representation */}
                  <div className="flex items-center gap-1 text-[10px] font-bold flex-shrink-0">
                      <span className="text-muted-foreground font-semibold">
                      {formatShortDate(previewItem.date, localeCode, t('assignDate.noDate'))}
                    </span>

                    {isDateable && (
                      <div className="flex items-center gap-1 animate-fade-in duration-200">
                        <ChevronRight className={`h-2 w-2 text-muted-foreground ${isRtl ? 'rotate-180' : ''}`} />
                        {actionType === 'associate' ? (
                          <span className="px-1.5 py-0.5 rounded-md bg-muted border border-border text-foreground font-bold shadow-xs">
                            {formatShortDate(selectedDate, localeCode, t('assignDate.noDate'))}
                          </span>
                        ) : previewItem.date ? (
                          <span className="px-1.5 py-0.5 rounded-md bg-red-50 border border-red-100 text-red-600 font-bold shadow-xs line-through">
                            {formatShortDate(previewItem.date, localeCode, t('assignDate.noDate'))}
                          </span>
                        ) : (
                          <span className="text-muted-foreground font-medium italic">{t('assignDate.noChange')}</span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {remainingItemsCount > 0 && (
              <div className="text-center py-1 text-[10px] font-bold text-muted-foreground italic">
                {t(remainingItemsCount === 1 ? 'assignDate.moreOne' : 'assignDate.moreMany', { count: number.format(remainingItemsCount) })}
              </div>
            )}
          </div>
        </div>
      </div>
    </Modal>
  );
};

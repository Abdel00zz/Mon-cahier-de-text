import { FC, useEffect, useRef, useState, useMemo } from 'react';
import { Modal } from '@/components/ui/modal';
import { Sigma } from '@/components/ui/icons';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { MathJax } from 'better-react-mathjax';
import { hasMathSyntax } from '@/utils/math';
import { useLocale } from '@/i18n/LocaleProvider';

interface DescriptionModalProps {
  isOpen: boolean;
  title: string;
  initialValue: string;
  onClose: () => void;
  onSave: (value: string) => void;
}

export const DescriptionModal: FC<DescriptionModalProps> = ({
  isOpen,
  title,
  initialValue,
  onClose,
  onSave,
}) => {
  const { t } = useLocale();
  const [value, setValue] = useState(initialValue);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    setValue(initialValue);
    requestAnimationFrame(() => inputRef.current?.focus());
  }, [isOpen, initialValue]);

  const hasMath = useMemo(() => {
    return hasMathSyntax(value);
  }, [value]);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={title}
      description={t('descriptionModal.description')}
      maxWidth="lg"
      footer={
        <div className="flex justify-between w-full">
          <Button
            type="button"
            variant="destructive"
            onClick={() => onSave('')}
            disabled={!initialValue}
            className="rounded-xl font-semibold px-4 shadow-sm"
          >
            {t('descriptionModal.clear')}
          </Button>
          <div className="flex gap-2">
            <Button type="button" variant="secondary" onClick={onClose} className="rounded-xl">
              {t('common.cancel')}
            </Button>
            <Button 
              type="button" 
              onClick={() => onSave(value)}
              className="rounded-xl bg-primary hover:bg-primary/90 font-semibold px-4 shadow-sm text-primary-foreground"
            >
              {t('common.save')}
            </Button>
          </div>
        </div>
      }
    >
      <div className="space-y-4">
        <Textarea
          ref={inputRef}
          value={value}
          onChange={event => setValue(event.target.value)}
          rows={6}
          className="w-full min-h-[140px] rounded-xl border border-border focus:ring-0 focus:border-border"
          placeholder={t('descriptionModal.placeholder')}
        />

        {/* Real-time LaTeX Preview Area */}
        {hasMath && (
          <div className="p-3.5 rounded-xl border border-border bg-muted/50 space-y-1.5 animate-fade-in duration-200">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-foreground flex items-center gap-1.5 uppercase tracking-wider">
                <Sigma className="h-3 w-3" />
                <span>{t('descriptionModal.preview')}</span>
              </span>
              <span className="text-[9px] text-muted-foreground font-medium">{t('descriptionModal.generated')}</span>
            </div>
            <div className="bg-card p-3 rounded-lg border border-border shadow-inner text-xs text-foreground leading-relaxed overflow-x-auto min-h-[45px] max-h-[150px] overflow-y-auto">
              <MathJax hideUntilTypeset="first">
                <div className="whitespace-pre-wrap break-words">
                  {value}
                </div>
              </MathJax>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};
